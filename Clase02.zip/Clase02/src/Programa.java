import java.util.Scanner;
public class Programa {
	public static void main(String[] args){
		//punto de entrada
		//user:	root	pass: 123
		Scanner sc=new Scanner(System.in);
		System.out.println("*****************************************");
		System.out.println("*         Sistema de Gestión            *");
		System.out.println("*****************************************");
		System.out.println();
		System.out.print("Ingrese su nombre de usuario: ");
		String user=sc.next();
		System.out.println();
		System.out.print("Ingrese su clave: ");
		String pass=sc.next();
		
		if(user.equals("root") && pass.equals("123")){
			System.out.println("permiso de entrada aceptado");
			System.out.println("Bienvenido usario "+user+"!");
		} else {
			System.out.println("permiso de entrada denegado");
			System.out.println("Usuario o clave incorrecta!");
		}
		
		
	}
}
