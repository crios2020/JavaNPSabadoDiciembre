import java.util.Scanner;

public class Clase02 {

	public static void main(String[] args) {
		// Clase 02 estructura condicional if
		
		boolean log1=true;
		int nro1=4;
		
		if(log1==true) {
			System.out.println("Verdad 1");
			//indentado
		}
		
		if(log1) {
			System.out.println("Verdad 2");
		}
		
		if(nro1==4) {
			System.out.println("Verdad 3");
		}
		
		if(nro1==4) {
			System.out.println("Verdad 4");
			System.out.println("Verdad 4");
		}
		
		//uso de llaves
		//forma no recomendada para java
		if(nro1==4) 
		{
			System.out.println("Verdad 5");
			System.out.println("Verdad 5");
		}
		
		//forma abreviada de uso de llaves
		if(nro1==5) 
			System.out.println("Verdad 6");
		System.out.println("hola");
		
		//sin llaves in line
		if(nro1==6) System.out.println("Verdad 7");
		
		
		//Estructura if else
		if(nro1==4) {
			//bloque verdadero
			System.out.println("Verdad 8");
		} else {
			//bloque false
			System.out.println("Falso 8");
		}
		
		//uso de llave
		//no recomendado en java
		if(nro1==4)
		{
			System.out.println("Verdad 9");
		}
		else
		{
			System.out.println("Falso 9");
		}
		
		//Modo abreviado sin llave
		if(nro1==4)	
			System.out.println("Verdad 10");
		else 
			System.out.println("Falso 10");
		
		//Modo abreviado sin llaves in line
		if(nro1==4)	System.out.println("Verdad 11");
		else System.out.println("Falso 11");
		
		//Operador condicional Ternario ?
		System.out.println((nro1==4)?"Verdad 12":"Falso 12");
		
		//Ingreso de datos desde consola
		Scanner sc=new Scanner(System.in);		//inicializa Scanner
		System.out.println("Ingrese su nombre:");
		//String nombre=sc.next();
		//System.out.println("Hola "+nombre);
		
		//If Anidado
		int nro2,nro3;
		nro1=280;
		nro2=250;
		nro3=420;
		
		//decir cual número es mayor
		
		if(nro1>nro2) {
			if(nro1>nro3) {
				System.out.println("nro1 es el mayor!");
			}else {
				System.out.println("nro3 es el mayor!");
			}
		} else {
			if(nro2>nro3) {
				System.out.println("nro2 es el mayor!");
			}else {
				System.out.println("nro3 es el mayor!");
			}
		}
		
		
		if(nro1>nro2 && nro1>nro3) System.out.println("nro1 es el mayor!");
		if(nro2>nro1 && nro2>nro3) System.out.println("nro2 es el mayor!");
		if(nro3>nro1 && nro3>nro2) System.out.println("nro3 es el mayor!");
			
		
		//Estructura Switch Case
		int nro=25;
		switch(nro) {
			case 1:	System.out.println("Valor 1"); break;
			case 2: System.out.println("Valor 2"); break;
			case 3: System.out.println("Valor 3");
			case 4: System.out.println("Valor 4");
			case 5: System.out.println("Valor 5"); break;
			case 6: case 7: case 8: case 9: case 10:
				System.out.println("Valor entre 6 y 10"); break;
			default: System.out.println("el valor es otro!");
		}
		
		//Estrucutra de repetición While
		int a=1;
		System.out.println("-- Inicio de While --");
		while(a<=10) {
			System.out.println(a);
			a++;
		}
		System.out.println("-- Fin de While --");
		System.out.println(a);
		
		//uso de llaves
		//modo no recomendado para java
		while(a<=10) 
		{
			System.out.println(a);
			a++;
		}
		
		//modo abreviado
		a=1;
		while(a<=10) System.out.println(a++);
		
		//loop infinito
		//a=1;
		//while (true) {
		//	System.out.println(a);
		//	a++;
		//}
		
		//loop infinito
		//a=1;
		//while(a<=10 || true) {
		//	System.out.println(a);
		//	a++;
		//}
		
		//loop infinito
		//a=1;
		//while(a<=10 || a>=1) {
		//	System.out.println(a);
		//	a++;
		//}
		
		//loop infinito
		//a=1;
		//while(a<=10) {
		//	System.out.println(a--);
		//	a++;
		//}
		
		//loop infinito
		//a=1;
		//while(a<=10);
		//{
		//	System.out.println(a);
		//	a++;
		//}
		
		//Estructura do while
		a=1;
		System.out.println("-- Inicio Estructura do while --");
		do {
			System.out.println(a);
			a++;
		}while(a<=10);
		System.out.println("-- Fin de Estructura do while --");
		System.out.println(a);
		
		//System.out.println("Fin del programa!");
	}

}
