
public class Clase01 {

	public static void main(String[] args) {
		/*
		 *	Curso: Java No Programadores	15 hs.
		 *	Días: Sábados. 15:00 a 18:00 hs.
		 *	Profe: Carlos Ríos	carlos.rios@educacionit.com
		 *	Materiales:	alumni.educacionit.com
		 *				user: email
		 *				pass: dni
		 *				
		 *				https://github.com/crios2020/JavaNPSabadoDiciembre
		 *
		 *	Software:	JDK:	Java Development Kit	8.X o 11.X o 17.X
		 *
		 *				IDE:	Integrated Development Enviroment	
		 *				Eclipse - Spring Tools Suite - Netbeans - IntelliJ - JDeveloper
		 */
		
		// comentarios de una sola linea
		
		/* Bloque de comentarios */
		
		System.out.println("Hola Mundo!");		// imprime en consola "Hola Mundo!"
		
		//syso	ctrol - espacio:	atajo de teclado para System.out.println();
		System.out.println("Curso de Java!");
		System.out.print("1");
		System.out.print("2");
		System.out.print("3");
		System.out.println("4");
		System.out.println("EducacionIT");
		
		/*
		 * Hola Mundo!
		 * Curso de Java!
		 * 1234
		 * EducacionIT
		 * 
		 */
		
		// Variables
		// Almacena un dato en memoria RAM
		
		// Lenguajes Tipados: JAVA C++, C#, Visual Basic
		
		// Lenguajes No Tipado: PHP, Python, JavaScript
		
		// Tipo de datos primitivos.
		
		// Tipo de datos int
		int a;					//declare la variable a
		a=2;					//asigne valor a la variable
		
		int b=3;				//declare y asigne valor a la variable b.
		//b="hola";				//error: se debe respetar el tipo de datos.
		
		int c=a+b;				//5
		
		int d=4,e=98,f=26,g=14;	//declaración y asignación multiple.
		
		System.out.println(a);
		System.out.println("variable a="+a);
		System.out.println("a+b="+a+b); 			//a+b=23
		System.out.println("a+b="+(a+b)); 			//a+b=5
		
		a=5;
		a=87;
		a=4;
		
		//Tipo de datos String (texto)
		String p="recreo";
		String q="cafe";
		System.out.println(p+q);
		System.out.println(p+" "+q);
		System.out.println(p+" y "+q);
		
		// Tipo de datos float		32 bits
		float fl=4.56f;
		System.out.println(fl);
		
		// tipo de datos double		64 bits
		double dl=4.56;
		System.out.println(dl);
		
		fl=10;
		dl=10;
		
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		fl=100;
		dl=100;
		
		System.out.println(fl/3);
		System.out.println(dl/3);
		
		//Tipo de datos boolean
		boolean bo=true;
		System.out.println(bo);
		bo=false;
		System.out.println(bo);
		
		//Tipo de datos char
		char ch=65;
		System.out.println(ch);
		
		//Operadores de lenguaje
		
		//Operador de asignación =
		//Operador de comparación ==
		
		int nro1=5;
		int nro2=7;
		
		System.out.println(nro1=nro2);
						//   <---
		
		System.out.println(nro1);
		System.out.println(nro2);
		
		// Sumar 1 a la variable nro1		++
		nro1++;		//nro1=nro1+1
		System.out.println(nro1);
		
		// Restar 1 a la variable nro1		--
		nro1--;		//nro1=nro1-1
		System.out.println(nro1);
		
		// Sumar 5 a la variable nro1		+=
		nro1 += 5;	//nro1=nro1+5
		System.out.println(nro1);
		
		// Restar 5 a la variable nro1		-=
		nro1-=5;	//nro1=nro1-5
		System.out.println(nro1);
		
		// multiplicar						*=
		nro1*=5;	//nro1=nro1*5;
		System.out.println(nro1);
		
		// dividir							/=
		nro1/=5;	//nro1=nro1/5
		System.out.println(nro1);
		
		//precedencia y procedencia de operador ++ --
		System.out.println(nro1++);
		System.out.println(nro1);
		System.out.println(++nro1);
		
		/*
		 * Operadores Lógicos
		 * 
		 * 	&&			and
		 * 	||			or
		 *  ==			equals
		 *  !=			not equals
		 *  !			not
		 *  > >=
		 *  < >=
		 */
		
		/*
		 * Tabla de verdad
		 * 
		 * 		X			Y				OR				AND
		 * 		F			F				F				F
		 * 		F			V				V				F
		 * 		V			F				V				F
		 * 		V			V				V				V
		 */
		
		nro1=10;
		nro2=10;
		
		boolean log1=true;
		boolean log2=false;
		
		System.out.println(log1 || log2);
		System.out.println(log1 && log2);
		
		//Operadores binarios | &
		
		System.out.println(log1|log2);
		
		System.out.println(log2 && log1);
		System.out.println(log2 & log1);
		
		System.out.println(log1);			//true
		System.out.println(!log1);			//false
		System.out.println(!!log1); 		//true
		System.out.println(!!!log1); 		//false
		System.out.println(!!!!log1); 		//true
		
		System.out.println(nro1==10);		//true
		System.out.println(nro1==11);		//false
		System.out.println(nro1!=10);		//false
		System.out.println(nro1!=11);		//true
		
		System.out.println(nro1<10);
		System.out.println(nro1<=10);
		//														f	o	f	  o			v
		System.out.println(!log2 && !!log1 && nro1==(5+5) && (log2 || nro1<=4 || nro1+2>=nro1));
		//					 V	  y    V    y      V      y          v
		
	}
	

}
