import java.text.DecimalFormat;

public class Clase03 {

	public static void main(String[] args) {
		// Clase 03

		int i=1;
		System.out.println("-- Inicio de estructura While --");
		while (i<=10) {
			System.out.println(i);
			i++;
		}
		System.out.println("Fin de esctructura While --");
		System.out.println(i);
		
		//Estructura for
		System.out.println("-- Inicio de estrucutra for --");
		for(int a=1;a<=10;a++) {
			System.out.println(a);
		}
		System.out.println("-- Fin de estructura for --");
		//System.out.println(a); //Error no se puede usar la variable por que se destruyo
		
		//uso de llaves
		//modo no recomendado
		for(int a=1;a<=10;a++)
		{
			System.out.println(a);
		}
		
		//modo Abreviado
		for(int a=1;a<=10;a++) System.out.println(a);
		
		//recorrido con variable global
		//i=1;
		System.out.println("***********************************************************");
		for(i=1; i<=10 ; i++) {
			System.out.println(i);
		}
		System.out.println("***********************************************************");
		System.out.println(i);
		System.out.println("***********************************************************");
		for(i++; i<=20;i++) {
			System.out.println(i);
		}
		System.out.println("***********************************************************");
		for(;i<=30;i++) {
			System.out.println(i);
		}
		
		//recorrido con varias variables de control
		for( int r=1,x=1 ; r<=5 && x<=10 ; r++, x++) {
			System.out.println(r+" "+x);
		}
		System.out.println("***********************************************************");
		for( int r=1,x=1 ; r<=5 || x<=10 ; r++, x++) {
			System.out.println(r+" "+x);
		}
		
		// for anidado
		int cont=1;
		for(int r=1;r<=10;r++) {
			for(int s=1;s<=10;s++) {
				for(int x=1;x<=10;x++){
					System.out.println(r+", "+s+", "+x+", "+cont++);
				}
			}
		}
		
		// Horas del Día
		DecimalFormat df=new DecimalFormat("00");	//siempre dos digitos enteros
		for(int hora=0; hora<24; hora++) {
			for(int minuto=0; minuto<60; minuto++) {
				for(int segundo=0; segundo<60; segundo++) {
					System.out.println(df.format(hora)+":"+df.format(minuto)+":"+df.format(segundo));
					//try { Thread.sleep(1000); } catch (Exception e) {}
				}
			}
		}
		
		DecimalFormat df2=new DecimalFormat("###,###,###.00");
		double precio=20000000.50;
		System.out.println(precio);
		System.out.println(df2.format(precio));
		
		//loop infinito
		//for(;;) {
		//	System.out.println("x");
		//}
		
		//loop infinito
		//for(int a=1;true;a++) System.out.println(a);
		
		//for(int a=1;a<=10 || true; a++) System.out.println(a);
		
		//for(int a=1;a<=10 || a>=10; a++) System.out.println(a);
		
		//for(int a=1;a<=10;) System.out.println(a);
		
		//for(int a=1;a<=10;a++) System.out.println(a-=2);
		
		int b=2;
		
		//for(int a=b;b<=10;a++) System.out.println(a);
		//for(int a=b;a<=10;b++) System.out.println(b);
		
		//Vectores
		
		
	}

}
