
public class Practica {

	public static void main(String[] args) {
		// Laboratorios Prácticos
		
		// Imprimir números del 20 a 1 salteando de 2 en 2.
		for (int a=20;a>=1;a-=2) { 
			System.out.println(a); 
		} 
		
		// Sumar los números del 1 al 10
		//System.out.println(1+2+3+4+5+6+7+8+9+10);
		int sumador=0;
		//for (int a=1 ;a<=10;a++) { 
		//	sumador+=a;
		//}
		
		int i=1;
		while(i<=10) {
			sumador+=i;
			i++;
		}
		
		System.out.println("Total: "+sumador);
		
		
		
	}

}
