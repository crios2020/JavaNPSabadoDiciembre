public class Vectores {
	public static void main(String[] args) {
		//Vectores o Arrays
		
		int[] numeros=new int[4];
		String[] nombres=new String[4];
		numeros[0]=1;
		nombres[0]="Juan";
		numeros[1]=2;
		nombres[1]="Laura";
		numeros[2]=3;
		nombres[2]="Graciela";
		numeros[3]=4;
		nombres[3]="Jose";
		
		//Fuera de rango
		//numeros[4]=5;
		//nombres[4]="Mirta";
		
		/*
		 * 		indice		numeros		nombres
		 * 			0			1		Juan
		 * 			1			2		Laura
		 * 			2			3		Graciela
		 * 			3			4		Jose
		 */
		
		//System.out.println(numeros[2]+" "+nombres[2]);
		
		//Recorrido del vector
		for(int a=0;a<4;a++) {
			System.out.println(numeros[a]+" "+nombres[a]);
		}
		
		//Método length
		System.out.println("longitud vector numeros: "+numeros.length);
		
		//Recorrido usando el método length
		for (int a=0;a<numeros.length;a++) {
			System.out.println(numeros[a]+" "+nombres[a]);
		}
		
		System.out.println("longitud vector args: "+args.length);
		for (int a=0;a<args.length;a++) {
			System.out.println(args[a]);
		}
		System.out.println("**********************************************");
		//Recorrido reverso
		for(int a=numeros.length-1;a>=0;a--) {
			System.out.println(numeros[a]+" "+nombres[a]);
		}
		
		//Recorrido usando estructura while
		System.out.println("**********************************************");
		int i=0;
		while(i<numeros.length) {
			System.out.println(numeros[i]+" "+nombres[i]);
			i++;
		}
		
		//Recorrido usando estructura doWhile
		System.out.println("**********************************************");
		i=0;
		do {
			System.out.println(numeros[i]+" "+nombres[i]);
			i++;
		} while(i<numeros.length);
		
		//declaración abreviada
		int[] vector= {12,12,23,43,1,5,2,10,12,8};
		
		System.out.println("Longitud Vector= "+vector.length);
		for(int a=0;a<vector.length;a++) {
			System.out.print(vector[a]+", ");
		}
		System.out.println();
		
		//Totalizar un vector numerico
		//Promediar un vector numericos
		int sumador=0;
		for(int a=0;a<vector.length;a++) {
			sumador+=vector[a];
		}
		System.out.println("Total: "+sumador);
		System.out.println("Promedio: "+((float)sumador/vector.length));
		
		//Operador %
		System.out.println(14%2); 					// 0
		System.out.println(15%2); 					// 1
		System.out.println(-15%2); 					//-1
		System.out.println(14%2); 					// 0
		
		//Sumar los números pares del vector
		sumador=0;
		for(int a=0;a<vector.length;a++) {
			if(vector[a]%2==0) sumador+=vector[a];
		}
		System.out.println("Total: "+sumador);
		
	}
}
