package clase05;

import javax.swing.JOptionPane;

public class Clase05 {

    public static void main(String[] args) {
        // Clase 05 Interfaz Gráfica
        
        /*
        AWT: Abstract Windows Type
            - Incorporada dentro del nucleo de java versión 1.0 .
            - Es la más veloz.
            - El sistema operativo es quien renderiza los componentes gráficos,
                suele verse distinta la apariencia en los distintos SOs.
            
        Swing:  
            - Java renderiza todos los componentes gráficos, asegurando la misma
                apariencia en todos los SOs.
        
        JavaFX:
            - Aparecio en java 6 y fue eliminado del nucleo de java version 11.
            - Cumple con el patron MVC.
            - Permitia crear aplicaciones Web Mobile y Desktop.
        
        */
        
        // invokar form Hola
        //new Hola().setVisible(true);
        //new Gestion().setVisible(true);
        //new Calculadora().setVisible(true);
        
        
        // Clase JOptionPane
        //JOptionPane.showMessageDialog(null, "Hola a todos");
        JOptionPane.showMessageDialog(
                null, 
                "Ultima Clase", 
                "Chauu", 
                JOptionPane.INFORMATION_MESSAGE
        );
        
        String nombre=JOptionPane.showInputDialog(null,"Cual es su nombre?");
        JOptionPane.showMessageDialog(null, "Hola "+nombre);
        
    }
    
}
