package clase04;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.LocalTime;

public class Funciones {
    
    public static final String ANSI_BLACK = "\u001B[30m";
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_GREEN = "\u001B[32m";
    public static final String ANSI_YELLOW = "\u001B[33m";
    public static final String ANSI_BLUE = "\u001B[34m";
    public static final String ANSI_PURPLE = "\u001B[35m";
    public static final String ANSI_CYAN = "\u001B[36m";
    public static final String ANSI_WHITE = "\u001B[37m";
    public static final String ANSI_RESET = "\u001B[0m";
    
    //funciones
    
    /**
     *  Esta función imprime la hora en la consola.
     */
    public static void hora(){
        //comentario de una sola sola linea
        //Este comentario no sale del .class
        /*
        bloque de comentarios
        Este comentario no sale del .class
        */
        LocalTime lt=LocalTime.now();
        DecimalFormat df=new DecimalFormat("00");
        System.out.println(
                df.format(lt.getHour())+":"+
                df.format(lt.getMinute())+":"+
                df.format(lt.getSecond())
        );
    }
    
    /**
     * Esta función imprime la fecha en la consola.
     */
    public static void fecha(){
        LocalDate ld=LocalDate.now();
        DecimalFormat df=new DecimalFormat("00");
        System.out.println(
                df.format(ld.getDayOfMonth())+"-"+
                ld.getMonth()+"-"+
                ld.getYear()
        );
    }
    
    public static void javaVersion(){
        System.out.println(System.getProperty("java.version"));
    }
    
    public static void printRojo(String texto){
        System.out.println(ANSI_RED+texto+ANSI_RESET);
    }
    
    public static void printVerde(String texto){
        System.out.println(ANSI_GREEN+texto+ANSI_RESET);
    }
    
    public static void printAzul(String texto){
        System.out.println(ANSI_BLUE+texto+ANSI_RESET);
    }
}
