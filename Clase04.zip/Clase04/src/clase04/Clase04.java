package clase04;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class Clase04 {

    public static void main(String[] args) {
        // Clase04 Vectores - Arrays
        
        int x=2;
        //Bloque de software - Ambito de software
        {
            //int x=8;
            System.out.println(x);
            int y=4;
            System.out.println(y);
        }
        
        System.out.println(x);
        //System.out.println(y); //error: la variable no existe
        
        int y=10;   //puedo volver a declarar la variable y
        System.out.println(y);
        
        //Vectores
        
        //Vectores o Arrays
		
        int[] numeros=new int[4];
        String[] nombres=new String[4];
        numeros[0]=1;
        nombres[0]="Juan";
        numeros[1]=2;
        nombres[1]="Laura";
        numeros[2]=3;
        nombres[2]="Graciela";
        numeros[3]=4;
        nombres[3]="Jose";

        //Fuera de rango
        //numeros[4]=5;
        //nombres[4]="Mirta";

        /*
         * 		indice		numeros		nombres
         * 			0			1		Juan
         * 			1			2		Laura
         * 			2			3		Graciela
         * 			3			4		Jose
         */

        //System.out.println(numeros[2]+" "+nombres[2]);

        //Recorrido del vector
        for(int a=0;a<4;a++) {
                System.out.println(numeros[a]+" "+nombres[a]);
        }

        //Método length
        System.out.println("longitud vector numeros: "+numeros.length);

        //Recorrido usando el método length
        for (int a=0;a<numeros.length;a++) {
                System.out.println(numeros[a]+" "+nombres[a]);
        }

        System.out.println("longitud vector args: "+args.length);
        for (int a=0;a<args.length;a++) {
                System.out.println(args[a]);
        }
        System.out.println("**********************************************");
        //Recorrido reverso
        for(int a=numeros.length-1;a>=0;a--) {
                System.out.println(numeros[a]+" "+nombres[a]);
        }

        //Recorrido usando estructura while
        System.out.println("**********************************************");
        int i=0;
        while(i<numeros.length) {
                System.out.println(numeros[i]+" "+nombres[i]);
                i++;
        }

        //Recorrido usando estructura doWhile
        System.out.println("**********************************************");
        i=0;
        do {
                System.out.println(numeros[i]+" "+nombres[i]);
                i++;
        } while(i<numeros.length);

        //declaración abreviada
        int[] vector= {12,12,23,43,1,5,2,10,12,8};

        System.out.println("Longitud Vector= "+vector.length);
        for(int a=0;a<vector.length;a++) {
                System.out.print(vector[a]+", ");
        }
        System.out.println();

        //Totalizar un vector numerico
        //Promediar un vector numericos
        int sumador=0;
        for(int a=0;a<vector.length;a++) {
                sumador+=vector[a];     //sumador=sumador+vector[a];
        }
        System.out.println("Total: "+sumador);
        System.out.println("Promedio: "+((float)sumador/vector.length));

        //Operador %
        System.out.println(14%2); 					// 0
        System.out.println(15%2); 					// 1
        System.out.println(-15%2); 					//-1
        System.out.println(14%2); 					// 0

        //Sumar los números pares del vector
        sumador=0;
        for(int a=0;a<vector.length;a++) {
                if(vector[a]%2==0) sumador+=vector[a];
        }
        System.out.println("Total: "+sumador);

        //Buscar valor Máximo y Mínimo en un vector númerico
        //int[] vector= {12,12,23,43,1,5,2,10,12,8};
        int max=vector[0];      //12
        int min=vector[0];      //12
        
        for(int a=0;a<vector.length;a++){
            if(vector[a]>max) max=vector[a];    //43
            if(vector[a]<min) min=vector[a];    // 1
        }
        System.out.println("Valor Máximo= "+max);
        System.out.println("Valor Mínimo= "+min);
        
        
        //Contar cuantos números son pares y cuantos números son impares
        //Contar cuantas veces se repite el nro 12
        int contPar=0, contImpar=0, cont12=0;
        vector[0]=25;
        for(int a=0;a<vector.length;a++){
            if(vector[a]%2==0) contPar++;
            else contImpar++;
            if(vector[a]==12) cont12++;
        }
        System.out.println("Cantidad números pares: "+contPar);
        System.out.println("Cantidad números impares: "+contImpar);
        System.out.println("Cantidad números 12: "+cont12);
        
        // Recorrido foreach (sin usar indices) jdk 5 o sup,
        for(int o:vector) System.out.print(o+", ");
        System.out.println();
        
        // Ordenar un vector
        Arrays.sort(vector);
        for(int o:vector) System.out.print(o+", ");
        System.out.println();
        System.out.println("*************************************************");
        // Ordenar el vector en forma reversa
        for(int a=vector.length-1;a>=0; a--) System.out.print(vector[a]+", ");
        System.out.println();
        System.out.println("*************************************************");
        
        // Copia de vectores
        int[] pares={2,4,6,8,10};
        int[] impares=new int[pares.length];
        
        /*
            pares           impares     pares2
                2           ___         ___
                4           ___         ___
                6           ___         ___
                8           ___         ___
               10           ___         ___
        */
        
        for(int a=0;a<pares.length;a++) impares[a]=pares[a]-1;
        for(int a=0;a<pares.length;a++) System.out.println(pares[a]+", "+impares[a]);

        int[] pares2=new int[pares.length];
        System.arraycopy(pares, 0, pares2, 0, pares.length);
        for(int a=0;a<pares.length;a++) System.out.println(pares[a]+", "+pares2[a]);
       
        Funciones.hora();
        Funciones.fecha();
        Funciones.javaVersion();
        Funciones.printRojo("Curso de Java");
        Funciones.printVerde("Curso de Java");
        Funciones.printAzul("Curso de Java");
        
    }
    
}
