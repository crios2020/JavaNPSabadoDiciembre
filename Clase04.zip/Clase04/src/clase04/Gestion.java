package clase04;

import java.util.Scanner;

public class Gestion {
    public static void main(String[] args) {
        String[] usuarios = {"Juan","Laura","Ana","Javier"};
        String[] claves = {"123","321","abc","111"};
        
        System.out.println("*************************************************");
        System.out.println("*              Sistema de Gestión                ");
        System.out.println("*************************************************");
        System.out.println();
        System.out.print("Ingrese su nombre de usuario: ");
        String usuario = new Scanner(System.in).next();
        System.out.println();
        System.out.print("Ingrese su clave de acceso: ");
        String clave = new Scanner(System.in).next();
        System.out.println();
        
        //System.out.println(usuario=="Juan");
        //System.out.println(usuario.equals("Juan"));
        //System.out.println(usuario.equalsIgnoreCase(usuario));
        //System.out.println(usuario+" "+clave);
        
        boolean existe=false;
        int donde=0;
        
        for(int a=0;a<usuarios.length;a++){
            if(usuario.equals(usuarios[a])){
                existe=true;
                donde=a;
            }
        }
        
        //System.out.println(existe+" "+donde);
        
        if(existe){
            if(clave.equals(claves[donde])){
                System.out.println("Bienvenido "+usuario);
            } else {
                System.out.println("Clave Incorrecta!");
            }
        }else{
            System.out.println("El usuario es inexistente!!");
        }
        
        
    }
}
